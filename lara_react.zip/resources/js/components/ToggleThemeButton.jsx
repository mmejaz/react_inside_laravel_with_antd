function ToggleThemeButton() {
    return <></>;
}

export default ToggleThemeButton;
